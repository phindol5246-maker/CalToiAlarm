plugins { id("com.android.application") }
android {
 namespace = "com.example.caltoialarm"
 compileSdk = 35
 defaultConfig { applicationId = "com.example.caltoialarm"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "2.0" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
