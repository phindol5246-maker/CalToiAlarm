package com.example.caltoialarm;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;

public class MainActivity extends Activity {
 LinearLayout root;TextView status;Button in,out,exception;
 @Override public void onCreate(Bundle state){super.onCreate(state);
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(36,48,36,24);
  ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
  TextView title=new TextView(this);title.setText("🏢 칼퇴 알리미");title.setTextSize(28);root.addView(title);
  status=new TextView(this);status.setTextSize(18);status.setPadding(0,30,0,25);root.addView(status);
  in=button("출근",()->{if(WorkStore.clockIn(this))refresh();});
  out=button("퇴근",()->{if(WorkStore.clockOut(this,false))refresh();});
  exception=button("예외 퇴근 (반차/조퇴)",()->startActivity(new Intent(this,ExceptionActivity.class)));
  button("알림·알람 권한 설정",this::permissions);
  button("출퇴근 기록 보기",this::history);
  TextView help=new TextView(this);help.setText("홈 화면을 길게 눌러 '위젯'에서 칼퇴 알리미를 추가하세요. 상단 알림창에도 출퇴근 버튼이 표시됩니다. 시스템 정책상 알림을 완전히 강제 고정할 수는 없습니다.");help.setPadding(0,24,0,0);root.addView(help);
  permissionsIfNeeded();Scheduler.sync(this);refresh();
 }
 Button button(String text,Runnable run){Button b=new Button(this);b.setText(text);root.addView(b);b.setOnClickListener(v->run.run());return b;}
 void refresh(){boolean active=WorkStore.active(this);status.setText(WorkStore.status(this));in.setEnabled(!active);out.setEnabled(active && System.currentTimeMillis()>=WorkStore.due(this));exception.setEnabled(active);}
 @Override protected void onResume(){super.onResume();if(status!=null){Scheduler.sync(this);refresh();}}
 void permissionsIfNeeded(){if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=getPackageManager().PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},50);}
 void permissions(){
  if(Build.VERSION.SDK_INT>=31){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);if(!am.canScheduleExactAlarms()){
   try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));return;}catch(Exception ignored){}
  }}
  startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));
 }
 void history(){
  StringBuilder sb=new StringBuilder();
  try{JSONArray a=new JSONArray(WorkStore.prefs(this).getString("history","[]"));for(int i=a.length()-1;i>=0;i--){JSONObject r=a.getJSONObject(i);sb.append(WorkStore.fmt(r.getLong("start"))).append(" → ").append(WorkStore.fmt(r.getLong("end"))).append(r.optBoolean("exception")?" (예외)":"").append("\n");}}catch(Exception e){sb.append("기록을 읽을 수 없습니다");}
  new AlertDialog.Builder(this).setTitle("출퇴근 기록").setMessage(sb.length()==0?"기록 없음":sb.toString()).setPositiveButton("확인",null).show();
 }
}
