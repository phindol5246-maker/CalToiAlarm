package com.example.caltoialarm;
import android.content.*;
import android.widget.Toast;
public class ActionReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  String action=i.getAction();if(action==null)return;
  switch(action){
   case "IN":WorkStore.clockIn(c);break;
   case "OUT":WorkStore.clockOut(c,false);break;
   case "LOCKED":Toast.makeText(c,"퇴근시간 전입니다. 예외 퇴근을 이용하세요.",Toast.LENGTH_LONG).show();break;
  }
  Scheduler.sync(c);
 }
}
