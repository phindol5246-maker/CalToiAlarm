package com.example.caltoialarm;
import android.content.*;
public class AlarmReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  String action=i.getAction();int id="caltoi.alarm.101".equals(action)?101:102;
  if(WorkStore.active(c) && System.currentTimeMillis()>=WorkStore.due(c)-(id==101?WorkStore.TEN:0)
    && WorkStore.markReminderShown(c,id))Notice.alert(c,id);
  Scheduler.sync(c);
 }
}
