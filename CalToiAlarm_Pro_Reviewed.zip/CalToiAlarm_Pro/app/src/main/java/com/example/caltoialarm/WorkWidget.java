package com.example.caltoialarm;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.widget.RemoteViews;

public class WorkWidget extends AppWidgetProvider {
 static void refresh(Context c){
  AppWidgetManager m=AppWidgetManager.getInstance(c);
  int[] ids=m.getAppWidgetIds(new ComponentName(c,WorkWidget.class));
  for(int id:ids)update(c,m,id);
 }
 static void update(Context c,AppWidgetManager m,int id){
  RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.work_widget);
  boolean active=WorkStore.active(c),due=active && System.currentTimeMillis()>=WorkStore.due(c);
  v.setTextViewText(R.id.widgetStatus,WorkStore.status(c));
  v.setBoolean(R.id.widgetIn,"setEnabled",!active);
  v.setBoolean(R.id.widgetOut,"setEnabled",due);
  v.setBoolean(R.id.widgetException,"setEnabled",active);
  v.setOnClickPendingIntent(R.id.widgetIn,Notice.action(c,"IN",1));
  v.setOnClickPendingIntent(R.id.widgetOut,Notice.action(c,"OUT",2));
  v.setOnClickPendingIntent(R.id.widgetException,Notice.exception(c));
  m.updateAppWidget(id,v);
 }
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);}
}
