package com.example.caltoialarm;
import android.app.*;
import android.os.Bundle;
public class ExceptionActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);
  if(!WorkStore.active(this)){finish();return;}
  new AlertDialog.Builder(this).setTitle("예외 퇴근 확인")
   .setMessage("조퇴·반차 등으로 예정시간 전에 퇴근 처리할까요? 기록에 예외 퇴근으로 저장됩니다.")
   .setNegativeButton("취소",(d,w)->finish())
   .setPositiveButton("예외 퇴근",(d,w)->{WorkStore.clockOut(this,true);finish();})
   .setOnCancelListener(d->finish()).show();
 }
}
