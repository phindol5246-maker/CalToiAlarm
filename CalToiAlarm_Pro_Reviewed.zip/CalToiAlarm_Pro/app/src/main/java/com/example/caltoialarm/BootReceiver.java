package com.example.caltoialarm;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){Scheduler.sync(c);}
}
