package com.example.caltoialarm;
import android.app.*;
import android.content.*;
import android.os.Build;

public final class Notice {
 private Notice(){}
 static void channels(Context c){
  NotificationManager m=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26){
   NotificationChannel status=new NotificationChannel(WorkStore.CHANNEL,"출퇴근 고정 알림",NotificationManager.IMPORTANCE_LOW);
   status.setDescription("상단 알림창의 출퇴근 버튼");m.createNotificationChannel(status);
   NotificationChannel alerts=new NotificationChannel(WorkStore.ALERT,"퇴근시간 알림",NotificationManager.IMPORTANCE_HIGH);
   m.createNotificationChannel(alerts);
  }
 }
 static PendingIntent action(Context c,String action,int code){
  Intent i=new Intent(c,ActionReceiver.class).setAction(action);
  return PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 static PendingIntent exception(Context c){return PendingIntent.getActivity(c,9,new Intent(c,ExceptionActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static void showStatus(Context c){
  channels(c);
  Notification.Builder b=new Notification.Builder(c,WorkStore.CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
   .setContentTitle("칼퇴 알리미").setContentText(WorkStore.status(c)).setOngoing(true).setOnlyAlertOnce(true)
   .setContentIntent(PendingIntent.getActivity(c,3,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
  if(WorkStore.active(c)){
   if(System.currentTimeMillis()>=WorkStore.due(c))b.addAction(new Notification.Action.Builder(null,"퇴근",action(c,"OUT",2)).build());
   else b.addAction(new Notification.Action.Builder(null,"퇴근 잠금",action(c,"LOCKED",4)).build());
   b.addAction(new Notification.Action.Builder(null,"예외 퇴근",exception(c)).build());
  }else b.addAction(new Notification.Action.Builder(null,"출근",action(c,"IN",1)).build());
  try{((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(100,b.build());}catch(SecurityException ignored){}
 }
 static void alert(Context c,int id){
  if(!WorkStore.active(c))return;
  channels(c);
  String msg=id==101?"퇴근까지 10분 남았어요!":"퇴근시간이에요! 퇴근 버튼이 활성화됐어요.";
  Notification.Builder b=new Notification.Builder(c,WorkStore.ALERT).setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
   .setContentTitle("칼퇴 알리미").setContentText(msg).setAutoCancel(true)
   .setContentIntent(PendingIntent.getActivity(c,3,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
  try{((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id,b.build());}catch(SecurityException ignored){}
 }
}
