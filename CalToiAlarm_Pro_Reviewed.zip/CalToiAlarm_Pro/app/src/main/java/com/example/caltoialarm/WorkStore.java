package com.example.caltoialarm;
import android.content.*;
import org.json.*;
import java.text.*;
import java.util.*;

public final class WorkStore {
 static final String PREF="work_state";
 static final long NINE=9L*60*60*1000;
 static final long TEN=10L*60*1000;
 static final String CHANNEL="work_status_v2", ALERT="work_alerts_v2";
 private WorkStore() {}
 static synchronized boolean markReminderShown(Context c,int id){
  if(!active(c))return false;
  String key="shown_"+id;
  long session=start(c);
  if(prefs(c).getLong(key,0)==session)return false;
  return prefs(c).edit().putLong(key,session).commit();
 }
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
 static long start(Context c){return prefs(c).getLong("start",0);}
 static long end(Context c){return prefs(c).getLong("end",0);}
 static boolean active(Context c){return start(c)>0 && end(c)==0;}
 static long due(Context c){return start(c)+NINE;}
 static String fmt(long millis){return new SimpleDateFormat("MM/dd HH:mm",Locale.KOREA).format(new Date(millis));}
 static synchronized boolean clockIn(Context c){
  if(active(c))return false;
  long now=System.currentTimeMillis();
  prefs(c).edit().putLong("start",now).putLong("end",0).putBoolean("exception",false).apply();
  Scheduler.sync(c); return true;
 }
 static synchronized boolean clockOut(Context c,boolean exception){
  if(!active(c))return false;
  if(!exception && System.currentTimeMillis()<due(c))return false;
  long now=System.currentTimeMillis();
  try {
   JSONArray rows=new JSONArray(prefs(c).getString("history","[]"));
   JSONObject row=new JSONObject();row.put("start",start(c));row.put("end",now);row.put("exception",exception);rows.put(row);
   prefs(c).edit().putString("history",rows.toString()).putLong("end",now).putBoolean("exception",exception).apply();
  }catch(JSONException e){return false;}
  Scheduler.sync(c);return true;
 }
 static String status(Context c){
  if(active(c)){
   long remaining=due(c)-System.currentTimeMillis();
   return "출근 "+fmt(start(c))+" · 퇴근 "+fmt(due(c))+(remaining>0?" · "+((remaining+59999)/60000)+"분 남음":" · 퇴근 가능");
  }
  if(start(c)>0)return "퇴근 완료 "+fmt(end(c));
  return "출근 버튼을 눌러 시작하세요";
 }
}
