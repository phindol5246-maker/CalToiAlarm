package com.example.caltoialarm;
import android.app.*;
import android.content.*;
import android.os.Build;

public final class Scheduler {
 private Scheduler(){}
 static PendingIntent alarmPi(Context c,int id){Intent i=new Intent(c,AlarmReceiver.class).setAction("caltoi.alarm."+id);return PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static void cancel(Context c,int id){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);am.cancel(alarmPi(c,id));}
 static void set(Context c,int id,long when){
  if(when<=System.currentTimeMillis())return;
  AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  PendingIntent pi=alarmPi(c,id);
  if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
  else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
 }
 static void sync(Context c){
  cancel(c,101);cancel(c,102);
  if(WorkStore.active(c)){
   set(c,101,WorkStore.due(c)-WorkStore.TEN);
   set(c,102,WorkStore.due(c));
  }
  WorkWidget.refresh(c); Notice.showStatus(c);
 }
}
