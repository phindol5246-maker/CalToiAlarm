# 칼퇴 알리미 v2 — Android Studio 프로젝트

갤럭시 S25용 네이티브 Android 앱. **무료 / 광고 없음 / 계정 불필요 / 로컬 기록**.

## 기능
- 홈 화면 위젯: 출근, 퇴근(9시간 후 활성화), 예외 퇴근(확인창)
- 상단 알림: 출근·퇴근 액션과 예외 퇴근. 안드로이드 시스템 정책상 사용자가 알림을 끌 수 있으며, 버튼은 알림창을 펼쳐야 보일 수 있습니다.
- 출근 시각 기록, 9시간 후 퇴근 가능, 10분 전/정각 알림
- 재부팅, 앱 업데이트, 시간 변경, 정확한 알람 권한 변경 시 알람 재설정
- 재출근/중복 출근 방지, 로컬 출퇴근 이력

## PC에서 빌드
1. Android Studio (JDK 17 권장) 설치
2. **이 폴더**를 Open으로 열기
3. Gradle 동기화 (AGP 8.7.3, Gradle 8.9, SDK 35 다운로드 필요)
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. app/build/outputs/apk/debug/app-debug.apk 를 갤럭시로 복사하여 설치

이 압축에는 Gradle wrapper JAR가 포함되지 않습니다. Android Studio 내장 Gradle 또는 시스템 Gradle 8.9로 열거나, GitHub Actions 워크플로를 사용하세요.

## GitHub Actions로 APK 생성
저장소 루트에 이 프로젝트를 올리고 Actions > Build debug APK > Run workflow를 누르세요. 성공 후 Artifacts에서 APK 다운로드.

## 권한 및 테스트
- Android 13+ 알림 허용 필수
- 설정 > 앱 > 칼퇴 알리미 > 알림 허용
- 앱의 '알림·알람 권한 설정'에서 정확한 알람 허용 (거부 시 시간 오차 가능)
- 갤럭시 배터리 제한 설정에서 제한 없음 / 절전 앱 제외 권장
- 상단 알림은 Android 정책상 절대 강제 고정 불가; 일부 환경에서 사용자가 해제하거나 숨길 수 있음
- 앱의 UI/예약/재부팅 동작은 **실제 갤럭시에서 검증 필요**

## 기술 메모
- AlarmManager RTC_WAKEUP, canScheduleExactAlarms() 확인 후 exact / inexact fallback
- Android AppWidget + Notification actions + BroadcastReceiver + SharedPreferences
- 예약은 고유 PendingIntent 101/102로 교체/취소
- 예외 퇴근은 확인창에서만 실행
- targetSdk 35

## 알려진 제한
- 앱을 강제 종료(force stop)한 경우 안드로이드가 알람과 리시버를 제한할 수 있음
- 잠금 화면/알림창 표시 정책은 One UI 설정에 따름
- 홈 위젯 버튼은 9시간 후 정각 알람 수신 때 새로 활성화됨 (정확한 알람 권한이 없으면 지연 가능)
- 출근 완료 후 같은 날이라도 퇴근하면 다시 출근할 수 있음. 일별 1회 제한은 적용하지 않음
